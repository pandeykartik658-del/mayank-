import { motion } from "framer-motion";

export function About() {
  return (
    <section id="about" className="bg-paper text-ink">
      {/* Section Header */}
      <div className="border-t border-b border-ink/15 px-6 md:px-12 py-5 flex items-center justify-between">
        <span className="text-[11px] uppercase tracking-[0.25em] text-ink/50">05 — About</span>
        <span className="text-[11px] uppercase tracking-[0.25em] text-ink/50">Studio</span>
      </div>

      <div className="px-6 md:px-12 py-24 md:py-32 max-w-[1600px] mx-auto flex flex-col gap-28 md:gap-40">
        
        {/* ABOUT US BLOCK */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-20 items-center">
          <div className="md:col-span-5">
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl uppercase tracking-[0.1em] flex items-center gap-5 mb-10">
              About Us <span className="text-2xl text-ink/15">✦</span>
            </h2>
            <div className="aspect-[4/3] w-full overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=80" 
                alt="Architecture Landscape" 
                className="w-full h-full object-cover grayscale"
              />
            </div>
          </div>
          <div className="md:col-start-7 md:col-span-6 flex flex-col justify-center">
            <h3 className="font-display text-xl md:text-2xl lg:text-3xl leading-[1.3] tracking-[0.08em] uppercase mb-10">
              We build it, because we love it. And to design a tale people will not forget.
            </h3>
            <div className="w-12 h-px bg-ink/20 mb-10" />
            <p className="text-base md:text-lg font-light leading-[1.8] text-ink/70 mb-6">
              LAAV Architecture is an architecture, masterplanning & design platform established 2022 by Laertis Antonios Ando Vassiliou, co-founder of OPA Open Platform for Architecture & Vassiliou AL.
            </p>
            <p className="text-base font-light leading-[1.8] text-ink/55">
              The practice aims to create a remarkable amount of larger, professionally driven scale & diverse design projects with global reach and cross-cultural scales and typologies.
            </p>
          </div>
        </div>

        {/* FOUNDER BLOCK */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-20 items-start">
          
          {/* Left Large Image */}
          <div className="md:col-span-5 relative aspect-[3/4] overflow-hidden bg-ink">
            <img 
              src="https://images.unsplash.com/photo-1556157382-97eda2d62296?w=1000&q=80" 
              alt="Founder" 
              className="w-full h-full object-cover absolute inset-0 grayscale opacity-50"
            />
            <div className="absolute inset-0 flex flex-col justify-center items-center text-paper font-display text-[15vw] md:text-[7vw] leading-[0.85] uppercase tracking-tighter opacity-15">
              <span>YOU</span>
              <span>ONLY</span>
              <span>LIVE</span>
              <span>ONCE</span>
            </div>
            <div className="absolute bottom-6 left-6 text-paper/60 text-[11px] uppercase tracking-[0.25em]">
              LAAV<sup className="text-[8px]">®</sup> — Est. 2022
            </div>
          </div>

          {/* Right Content */}
          <div className="md:col-start-7 md:col-span-6 flex flex-col justify-center pt-8 md:pt-0">
            <div className="flex items-center justify-between mb-10 pb-6 border-b border-ink/10">
              <h2 className="font-display text-3xl md:text-4xl uppercase tracking-[0.1em]">
                Founder
              </h2>
              <span className="text-[11px] uppercase tracking-[0.25em] text-ink/35">Est. 2022</span>
            </div>
            
            {/* Video Thumbnail */}
            <div className="aspect-video w-full relative overflow-hidden mb-10 group cursor-pointer">
              <img 
                src="https://images.unsplash.com/photo-1507676184212-d0c30a3fcfa2?w=1000&q=80" 
                alt="Founder Video" 
                className="w-full h-full object-cover grayscale transition-all duration-700 group-hover:grayscale-0 group-hover:scale-105"
              />
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-16 h-16 rounded-full bg-paper flex items-center justify-center group-hover:scale-110 transition-transform duration-500">
                  <div className="w-0 h-0 border-t-[5px] border-t-transparent border-l-[9px] border-l-ink border-b-[5px] border-b-transparent ml-0.5" />
                </div>
              </div>
            </div>
            
            <p className="text-[11px] uppercase tracking-[0.25em] text-ink/50 mb-8">
              What does it take to make world-class projects?
            </p>

            <div className="space-y-5 text-base font-light leading-[1.8] text-ink/65">
              <p>
                Laertis Antonios Ando Vassiliou (born in 1983) is a Greek / Japanese architect. He grew up in Rhodes and after a run to several working architectures (Athens, Florence, Amsterdam, Rome).
              </p>
              <p>
                In 2015 he founded the OPA Open Platform for Architecture platform, which allowed him to create the very successful project Casa Brutale (for a private client in Beirut). By way of short: from architectural design to interior design, art installation, conceptual ideas, up to his second project in Rhodes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
