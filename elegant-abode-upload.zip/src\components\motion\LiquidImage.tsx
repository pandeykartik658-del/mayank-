import { useEffect, useRef, useState, useCallback } from "react";

/**
 * LiquidImage — renders an image onto a canvas and applies a GPU-friendly
 * liquid-ripple distortion when the mouse interacts with it.
 * Falls back to a plain <img> on mobile / non-pointer devices.
 */
export function LiquidImage({
  src,
  alt,
  className,
  style,
}: {
  src: string;
  alt: string;
  className?: string;
  style?: React.CSSProperties;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const rafRef = useRef(0);
  const [loaded, setLoaded] = useState(false);
  const [isPointer, setIsPointer] = useState(false);

  // Ripple state
  const ripples = useRef<{ x: number; y: number; t: number; strength: number }[]>([]);
  const mousePos = useRef({ x: 0.5, y: 0.5 });
  const hovering = useRef(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      setIsPointer(window.matchMedia("(pointer: fine)").matches);
    }
  }, []);

  // Load image
  useEffect(() => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      imgRef.current = img;
      setLoaded(true);
    };
    img.src = src;
  }, [src]);

  // Render loop
  const render = useCallback(() => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    // Draw base image
    ctx.drawImage(img, 0, 0, w, h);

    // Process active ripples
    const now = performance.now();
    const activeRipples = ripples.current.filter((r) => now - r.t < 1200);
    ripples.current = activeRipples;

    if (activeRipples.length > 0 || hovering.current) {
      const imgData = ctx.getImageData(0, 0, w, h);
      const pixels = imgData.data;

      // Re-draw base
      ctx.drawImage(img, 0, 0, w, h);
      const baseData = ctx.getImageData(0, 0, w, h);
      const base = baseData.data;

      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          let dx = 0;
          let dy = 0;

          // Ripple displacements
          for (const r of activeRipples) {
            const rx = r.x * w;
            const ry = r.y * h;
            const dist = Math.sqrt((x - rx) ** 2 + (y - ry) ** 2);
            const age = (now - r.t) / 1200;
            const wave = Math.sin(dist * 0.15 - age * 12) * Math.exp(-dist * 0.015) * (1 - age);
            dx += wave * r.strength * 0.6;
            dy += wave * r.strength * 0.6;
          }

          // Subtle hover breathing
          if (hovering.current) {
            const mx = mousePos.current.x * w;
            const my = mousePos.current.y * h;
            const md = Math.sqrt((x - mx) ** 2 + (y - my) ** 2);
            const hover = Math.sin(md * 0.04 + now * 0.002) * Math.exp(-md * 0.006) * 2;
            dx += hover;
            dy += hover;
          }

          const sx = Math.round(Math.min(w - 1, Math.max(0, x + dx)));
          const sy = Math.round(Math.min(h - 1, Math.max(0, y + dy)));
          const si = (sy * w + sx) * 4;
          const di = (y * w + x) * 4;
          pixels[di] = base[si];
          pixels[di + 1] = base[si + 1];
          pixels[di + 2] = base[si + 2];
          pixels[di + 3] = base[si + 3];
        }
      }

      ctx.putImageData(imgData, 0, 0);
    }

    if (hovering.current || ripples.current.length > 0) {
      rafRef.current = requestAnimationFrame(render);
    }
  }, []);

  const startLoop = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(render);
  }, [render]);

  const handleMouseEnter = () => {
    hovering.current = true;
    startLoop();
  };

  const handleMouseLeave = () => {
    hovering.current = false;
    // Let the last frame play out
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const nx = (e.clientX - rect.left) / rect.width;
    const ny = (e.clientY - rect.top) / rect.height;
    mousePos.current = { x: nx, y: ny };

    // Spawn ripple at intervals
    const now = performance.now();
    const lastRipple = ripples.current[ripples.current.length - 1];
    if (!lastRipple || now - lastRipple.t > 80) {
      ripples.current.push({ x: nx, y: ny, t: now, strength: 8 });
    }
  };

  const handleClick = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const nx = (e.clientX - rect.left) / rect.width;
    const ny = (e.clientY - rect.top) / rect.height;
    ripples.current.push({ x: nx, y: ny, t: performance.now(), strength: 18 });
    startLoop();
  };

  // Size canvas on mount / resize
  useEffect(() => {
    if (!loaded || !isPointer) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      // Use a lower resolution for performance
      const dpr = Math.min(window.devicePixelRatio, 1.5);
      const rw = Math.round(rect.width * dpr * 0.5); // Half res for perf
      const rh = Math.round(rect.height * dpr * 0.5);
      canvas.width = rw;
      canvas.height = rh;
      render();
    };

    resize();
    window.addEventListener("resize", resize);
    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(rafRef.current);
    };
  }, [loaded, isPointer, render]);

  // Fallback for mobile
  if (!isPointer) {
    return (
      <img
        src={src}
        alt={alt}
        className={className}
        style={{ ...style, filter: "grayscale(70%) contrast(1.05) sepia(0.1)" }}
      />
    );
  }

  return (
    <canvas
      ref={canvasRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onMouseMove={handleMouseMove}
      onClick={handleClick}
      className={className}
      style={{
        ...style,
        filter: "grayscale(70%) contrast(1.05) sepia(0.1)",
        imageRendering: "auto",
      }}
      data-cursor="view"
    />
  );
}
