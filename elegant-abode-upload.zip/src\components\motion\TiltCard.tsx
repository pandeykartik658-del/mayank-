import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useRef, type ReactNode } from "react";

/**
 * TiltCard — Wraps its children in a 3D perspective container.
 * Rotates on X and Y axes based on mouse position relative to its center.
 * Renders a dynamic glare overlay that moves opposite to the tilt.
 */
export function TiltCard({
  children,
  className,
  maxTilt = 15,
}: {
  children: ReactNode;
  className?: string;
  maxTilt?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);

  // Mouse position relative to center [-1 to 1]
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  // Smooth springs for physics
  const springConfig = { stiffness: 150, damping: 20, mass: 0.5 };
  const sx = useSpring(x, springConfig);
  const sy = useSpring(y, springConfig);

  // Calculate rotations (opposite direction to mouse)
  const rotateX = useTransform(sy, [-1, 1], [maxTilt, -maxTilt]);
  const rotateY = useTransform(sx, [-1, 1], [-maxTilt, maxTilt]);

  // Glare position
  const glareX = useTransform(sx, [-1, 1], [0, 100]);
  const glareY = useTransform(sy, [-1, 1], [0, 100]);

  const onMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width;
    const ny = (e.clientY - rect.top) / rect.height;
    // Map from 0..1 to -1..1
    x.set(nx * 2 - 1);
    y.set(ny * 2 - 1);
  };

  const onMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <div
      ref={ref}
      style={{ perspective: "1000px" }}
      className={`relative ${className ?? ""}`}
      onMouseMove={onMouseMove}
      onMouseLeave={onMouseLeave}
    >
      <motion.div
        style={{
          rotateX,
          rotateY,
          transformStyle: "preserve-3d",
        }}
        className="w-full h-full relative"
      >
        {children}

        {/* Dynamic Glare Overlay */}
        <motion.div
          className="pointer-events-none absolute inset-0 z-50 mix-blend-screen opacity-50"
          style={{
            background: useTransform(
              [glareX, glareY],
              ([gx, gy]) =>
                `radial-gradient(circle at ${gx}% ${gy}%, rgba(255,255,255,0.2) 0%, transparent 50%)`
            ),
          }}
        />
      </motion.div>
    </div>
  );
}
