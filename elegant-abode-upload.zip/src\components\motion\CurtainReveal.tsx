import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef, type ReactNode } from "react";

/**
 * CurtainReveal — wraps a section and reveals it with a curtain wipe animation
 * triggered by scrolling into view.
 * Uses two panels that sweep apart (left-to-right and right-to-left).
 */
export function CurtainReveal({
  children,
  className,
  curtainColor = "var(--clay)",
  duration = 1.2,
}: {
  children: ReactNode;
  className?: string;
  curtainColor?: string;
  duration?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-10% 0px" });

  return (
    <div ref={ref} className={`relative overflow-hidden ${className ?? ""}`}>
      {children}

      {/* Left curtain panel */}
      <motion.div
        initial={{ x: "0%" }}
        animate={inView ? { x: "-105%" } : { x: "0%" }}
        transition={{ duration, ease: [0.83, 0, 0.17, 1], delay: 0.1 }}
        className="absolute inset-y-0 left-0 w-1/2 z-30 pointer-events-none"
        style={{ background: curtainColor }}
      />
      {/* Right curtain panel */}
      <motion.div
        initial={{ x: "0%" }}
        animate={inView ? { x: "105%" } : { x: "0%" }}
        transition={{ duration, ease: [0.83, 0, 0.17, 1], delay: 0.1 }}
        className="absolute inset-y-0 right-0 w-1/2 z-30 pointer-events-none"
        style={{ background: curtainColor }}
      />
    </div>
  );
}

/**
 * SectionWipe — a horizontal wipe that reveals content as user scrolls into the section.
 * Single panel from left to right.
 */
export function SectionWipe({
  children,
  className,
  color = "var(--ink)",
}: {
  children: ReactNode;
  className?: string;
  color?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "start 0.5"],
  });
  const wipeX = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  return (
    <div ref={ref} className={`relative overflow-hidden ${className ?? ""}`}>
      {children}
      <motion.div
        style={{ x: wipeX }}
        className="absolute inset-0 z-30 pointer-events-none"
      >
        <div className="absolute inset-0 -translate-x-full" style={{ background: color }} />
      </motion.div>
    </div>
  );
}
