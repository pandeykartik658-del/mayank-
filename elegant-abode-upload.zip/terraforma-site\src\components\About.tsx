import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function About() {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Text reveal
      gsap.fromTo('.abt-text', { opacity: 0, y: 60 }, {
        opacity: 1, y: 0, duration: 1.1, stagger: 0.12, ease: 'power3.out',
        scrollTrigger: { trigger: ref.current, start: 'top 65%' },
      });

      // Image
      gsap.fromTo('.abt-img', { scale: 1.12, opacity: 0 }, {
        scale: 1, opacity: 1, duration: 1.4, ease: 'power2.out',
        scrollTrigger: { trigger: '.abt-img', start: 'top 80%' },
      });

      // Parallax
      gsap.to('.abt-img-inner', {
        yPercent: -12, ease: 'none',
        scrollTrigger: { trigger: ref.current, start: 'top bottom', end: 'bottom top', scrub: 1.5 },
      });

      // Stats
      gsap.fromTo('.abt-stat', { opacity: 0, y: 25 }, {
        opacity: 1, y: 0, duration: 0.8, stagger: 0.1, ease: 'power2.out',
        scrollTrigger: { trigger: '.abt-stats', start: 'top 85%' },
      });
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={ref} id="aboutus" className="relative">
      {/* Top nav row */}
      <div className="max-w-[1400px] mx-auto px-8 md:px-14">
        <div className="flex items-center justify-between py-4 border-b border-[var(--rule)]">
          <span className="font-sans text-[10px] uppercase tracking-[0.12em] text-[var(--ink-soft)]">Next Project:</span>
          <div className="flex items-center gap-3">
            <span className="font-sans text-[10px] uppercase tracking-[0.12em] text-[var(--ink-soft)]">View Project:</span>
            <div className="arr-btn" style={{ width: 36, height: 36 }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-3.5 h-3.5">
                <path d="M7 17L17 7M17 7H7M17 7V17" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Main about content */}
      <div className="max-w-[1400px] mx-auto px-8 md:px-14 py-20 md:py-32">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-20">
          {/* Left — Text */}
          <div className="md:col-span-6">
            <div className="abt-text mb-5">
              <span className="font-sans text-[10px] uppercase tracking-[0.18em] text-[var(--ink-soft)]">About us</span>
              <div className="arr-btn-lg inline-flex ml-4 align-middle" style={{ width: 40, height: 40 }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-4 h-4">
                  <path d="M7 17L17 7M17 7H7M17 7V17" />
                </svg>
              </div>
            </div>

            <h2 className="abt-text font-serif text-[clamp(1.8rem,3.8vw,3.2rem)] leading-[1.15] mb-10">
              At TerraForma, we are dedicated to designing sustainable living spaces that harmonize with nature and inspire eco‑conscious lifestyles
            </h2>

            <p className="abt-text font-sans text-[12px] leading-[1.9] text-[var(--ink-soft)] max-w-[420px] mb-6">
              We believe in shaping a greener future by blending cutting-edge design with sustainable practices.
              From energy-efficient structures to the thoughtful use of natural materials, every project we
              undertake is a step towards preserving the environment for generations to come.
            </p>

            <a href="#" className="abt-text inline-flex items-center gap-3 font-sans text-[10px] uppercase tracking-[0.15em] text-[var(--ink)] hover:text-[var(--terra)] transition-colors group">
              <span>Learn more</span>
              <svg className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M5 12H19M19 12L12 5M19 12L12 19" />
              </svg>
            </a>
          </div>

          {/* Right — Image + Stats */}
          <div className="md:col-span-6">
            <div className="abt-img relative overflow-hidden aspect-[4/3] mb-10">
              <div className="abt-img-inner absolute inset-0 scale-[1.15]">
                <img
                  src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200&q=85&auto=format"
                  alt="Sustainable architecture"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Stats grid */}
            <div className="abt-stats grid grid-cols-2 gap-x-8 gap-y-6">
              {[
                { icon: '🌿', val: '100%', label: 'Eco-friendly materials only' },
                { icon: '☀️', val: '95%', label: 'Recycled construction waste' },
                { icon: '💧', val: '200+', label: 'Green-space coverage' },
                { icon: '⚡', val: '50%', label: 'Reduction in utility costs' },
              ].map((s, i) => (
                <div key={i} className="abt-stat flex items-start gap-3 py-4 border-t border-[var(--rule)]">
                  <span className="text-lg">{s.icon}</span>
                  <div>
                    <div className="font-serif text-xl font-semibold">{s.val}</div>
                    <span className="font-sans text-[10px] text-[var(--ink-soft)] leading-tight">{s.label}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-8 md:px-14">
        <div className="rule r-line" />
      </div>
    </section>
  );
}
