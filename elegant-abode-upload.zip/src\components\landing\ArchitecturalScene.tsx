import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

/**
 * ArchitecturalScene — renders three wireframe architectural massing models
 * that slowly rotate and respond to mouse movement.
 * Desktop-only; on mobile, renders a static SVG fallback.
 */
export function ArchitecturalScene({ className }: { className?: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPointer, setIsPointer] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      setIsPointer(window.matchMedia("(pointer: fine)").matches);
    }
  }, []);

  useEffect(() => {
    if (!isPointer || !containerRef.current) return;

    const container = containerRef.current;
    const rect = container.getBoundingClientRect();

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, rect.width / rect.height, 0.1, 100);
    camera.position.set(0, 2, 12);
    camera.lookAt(0, 0.5, 0);

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: "low-power",
    });
    renderer.setSize(rect.width, rect.height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);

    // Materials
    const wireMat = new THREE.LineBasicMaterial({
      color: new THREE.Color("hsl(30, 50%, 52%)"), // clay color
      transparent: true,
      opacity: 0.5,
    });

    const edgeMat = new THREE.LineBasicMaterial({
      color: new THREE.Color("hsl(30, 50%, 52%)"),
      transparent: true,
      opacity: 0.25,
    });

    const solidMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color("hsl(40, 15%, 14%)"), // ink
      transparent: true,
      opacity: 0.06,
      side: THREE.DoubleSide,
    });

    // Building 1 — Tower (tall, slender)
    const tower = new THREE.Group();
    const towerGeo = new THREE.BoxGeometry(1.2, 5, 1.2);
    const towerMesh = new THREE.Mesh(towerGeo, solidMat);
    const towerEdges = new THREE.LineSegments(new THREE.EdgesGeometry(towerGeo), wireMat);
    tower.add(towerMesh, towerEdges);

    // Setback levels
    const setback1Geo = new THREE.BoxGeometry(1.6, 0.3, 1.6);
    const setback1 = new THREE.LineSegments(new THREE.EdgesGeometry(setback1Geo), edgeMat);
    setback1.position.y = -1.5;
    tower.add(setback1);

    // Floor plates
    for (let i = 0; i < 8; i++) {
      const floorGeo = new THREE.PlaneGeometry(1.2, 1.2);
      const floor = new THREE.LineSegments(new THREE.EdgesGeometry(floorGeo), edgeMat);
      floor.rotation.x = -Math.PI / 2;
      floor.position.y = -2.5 + i * 0.7;
      tower.add(floor);
    }

    tower.position.set(-3, 2.5, 0);

    // Building 2 — Pavilion (wide, low, with cantilever)
    const pavilion = new THREE.Group();
    const baseGeo = new THREE.BoxGeometry(3, 1.2, 2);
    const baseMesh = new THREE.Mesh(baseGeo, solidMat);
    const baseEdges = new THREE.LineSegments(new THREE.EdgesGeometry(baseGeo), wireMat);
    pavilion.add(baseMesh, baseEdges);

    // Cantilever
    const cantGeo = new THREE.BoxGeometry(1.5, 0.15, 2.4);
    const cant = new THREE.LineSegments(new THREE.EdgesGeometry(cantGeo), wireMat);
    cant.position.set(2.2, 0.4, 0);
    pavilion.add(cant);

    // Columns
    for (let i = 0; i < 3; i++) {
      const colGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.2, 6);
      const col = new THREE.LineSegments(new THREE.EdgesGeometry(colGeo), edgeMat);
      col.position.set(2.2 + (i - 1) * 0.5, -0.2, 0);
      pavilion.add(col);
    }

    // Courtyard void
    const courtGeo = new THREE.PlaneGeometry(1, 1);
    const court = new THREE.LineSegments(new THREE.EdgesGeometry(courtGeo), wireMat);
    court.rotation.x = -Math.PI / 2;
    court.position.set(-0.5, 0.61, 0);
    pavilion.add(court);

    pavilion.position.set(0, 0.6, 0);

    // Building 3 — Residential block (stepped/terraced)
    const residential = new THREE.Group();
    const steps = [
      { w: 2, h: 1.5, d: 1.5, y: 0.75 },
      { w: 1.6, h: 1.2, d: 1.2, y: 2.1 },
      { w: 1.2, h: 0.9, d: 0.9, y: 3.15 },
    ];

    steps.forEach((s) => {
      const geo = new THREE.BoxGeometry(s.w, s.h, s.d);
      const mesh = new THREE.Mesh(geo, solidMat);
      mesh.position.y = s.y;
      const edges = new THREE.LineSegments(new THREE.EdgesGeometry(geo), wireMat);
      edges.position.y = s.y;
      residential.add(mesh, edges);
    });

    // Terrace lines
    steps.forEach((s, i) => {
      if (i < steps.length - 1) {
        const terrGeo = new THREE.PlaneGeometry(s.w, s.d);
        const terr = new THREE.LineSegments(new THREE.EdgesGeometry(terrGeo), edgeMat);
        terr.rotation.x = -Math.PI / 2;
        terr.position.y = s.y + s.h / 2 + 0.01;
        residential.add(terr);
      }
    });

    residential.position.set(3.5, 0, 0);

    // Ground plane
    const groundGeo = new THREE.PlaneGeometry(14, 8);
    const ground = new THREE.LineSegments(new THREE.EdgesGeometry(groundGeo), edgeMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = 0;

    // Grid on ground
    const gridHelper = new THREE.GridHelper(14, 28, new THREE.Color("hsl(30, 50%, 52%)"), new THREE.Color("hsl(30, 50%, 52%)"));
    (gridHelper.material as THREE.Material).opacity = 0.06;
    (gridHelper.material as THREE.Material).transparent = true;

    scene.add(tower, pavilion, residential, ground, gridHelper);

    // Mouse tracking
    const mouse = { x: 0, y: 0 };
    const onMouseMove = (e: MouseEvent) => {
      const r = container.getBoundingClientRect();
      mouse.x = (e.clientX - r.left) / r.width - 0.5;
      mouse.y = (e.clientY - r.top) / r.height - 0.5;
    };
    container.addEventListener("mousemove", onMouseMove);

    // Animation
    let animId = 0;
    const animate = () => {
      animId = requestAnimationFrame(animate);

      const time = performance.now() * 0.001;

      // Slow auto-rotation
      scene.rotation.y += (mouse.x * 0.8 - scene.rotation.y) * 0.02;
      camera.position.y += (2 + mouse.y * -1.5 - camera.position.y) * 0.02;
      camera.lookAt(0, 0.5, 0);

      // Gentle floating
      tower.position.y = 2.5 + Math.sin(time * 0.5) * 0.08;
      pavilion.position.y = 0.6 + Math.sin(time * 0.4 + 1) * 0.05;
      residential.position.y = Math.sin(time * 0.3 + 2) * 0.06;

      renderer.render(scene, camera);
    };
    animate();

    // Resize
    const onResize = () => {
      const r = container.getBoundingClientRect();
      camera.aspect = r.width / r.height;
      camera.updateProjectionMatrix();
      renderer.setSize(r.width, r.height);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", onResize);
      container.removeEventListener("mousemove", onMouseMove);
      container.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [isPointer]);

  return (
    <div
      ref={containerRef}
      className={className}
      data-cursor="explore"
      style={{ touchAction: "none" }}
    >
      {!isPointer && <WireframeFallback />}
    </div>
  );
}

/** Simple SVG fallback for touch/mobile */
function WireframeFallback() {
  return (
    <svg viewBox="0 0 400 200" className="w-full h-full opacity-20" fill="none" stroke="var(--clay)" strokeWidth="0.5">
      {/* Tower */}
      <rect x="40" y="20" width="40" height="160" />
      <line x1="40" y1="60" x2="80" y2="60" />
      <line x1="40" y1="100" x2="80" y2="100" />
      <line x1="40" y1="140" x2="80" y2="140" />
      {/* Pavilion */}
      <rect x="140" y="100" width="120" height="40" />
      <line x1="260" y1="100" x2="310" y2="100" />
      <line x1="260" y1="140" x2="310" y2="140" />
      <line x1="270" y1="100" x2="270" y2="180" strokeWidth="0.3" />
      <line x1="290" y1="100" x2="290" y2="180" strokeWidth="0.3" />
      {/* Residential */}
      <rect x="320" y="80" width="60" height="100" />
      <rect x="328" y="50" width="44" height="30" />
      <rect x="336" y="20" width="28" height="30" />
      {/* Ground */}
      <line x1="0" y1="180" x2="400" y2="180" strokeDasharray="2 4" />
    </svg>
  );
}
