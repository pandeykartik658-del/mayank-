import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const CARDS = [
  {
    num: '01',
    title: 'Sustainable\nArchitecture\nDesign',
    desc: 'Designing structures that minimize environmental impact while maximizing aesthetics and functionality.',
    img: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600&q=80&auto=format',
  },
  {
    num: '02',
    title: 'Green\nBuilding\nConsultation',
    desc: 'Expert guidance on sustainable construction materials, energy efficiency and eco-friendly practices.',
    img: 'https://images.unsplash.com/photo-1487958449943-2429e5be8624?w=600&q=80&auto=format',
  },
  {
    num: '03',
    title: 'Project\nPlanning\n& Development',
    desc: 'End-to-end project management for green developments, from concept to sustainable completion.',
    img: 'https://images.unsplash.com/photo-1448630360428-65456885c650?w=600&q=80&auto=format',
  },
];

export function Services() {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Section title
      gsap.fromTo('.svc-title', { opacity: 0, y: 50 }, {
        opacity: 1, y: 0, duration: 1.2, ease: 'power3.out',
        scrollTrigger: { trigger: ref.current, start: 'top 70%' },
      });

      // Cards stagger
      gsap.fromTo('.svc-card', { opacity: 0, y: 70 }, {
        opacity: 1, y: 0, duration: 1, stagger: 0.15, ease: 'power3.out',
        scrollTrigger: { trigger: '.svc-grid', start: 'top 80%' },
      });

      // Image parallax
      gsap.utils.toArray<HTMLElement>('.svc-img-inner').forEach((el) => {
        gsap.to(el, {
          yPercent: -10, ease: 'none',
          scrollTrigger: { trigger: el.closest('.svc-card') || el, start: 'top bottom', end: 'bottom top', scrub: 1.5 },
        });
      });
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={ref} id="services" className="py-20 md:py-32">
      <div className="max-w-[1400px] mx-auto px-8 md:px-14">
        {/* Services label */}
        <div className="flex items-center gap-3 mb-3 r-fade">
          <span className="font-sans text-[10px] uppercase tracking-[0.18em] text-[var(--ink-soft)]">Services</span>
        </div>

        {/* Title row */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14">
          <h2 className="svc-title font-serif text-[clamp(2rem,4.5vw,3.8rem)] leading-[1.1] max-w-[600px]">
            Crafting Sustainable<br />
            Solutions for Every Space
          </h2>
          <div className="flex items-center gap-4">
            <a href="#" className="font-sans text-[10px] uppercase tracking-[0.12em] text-[var(--ink-soft)] hover:text-[var(--terra)] transition-colors">
              View all
            </a>
            <div className="flex gap-2">
              <div className="arr-btn" style={{ width: 40, height: 40 }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-4 h-4 rotate-180">
                  <path d="M5 12H19M19 12L12 5M19 12L12 19" />
                </svg>
              </div>
              <div className="arr-btn" style={{ width: 40, height: 40 }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-4 h-4">
                  <path d="M5 12H19M19 12L12 5M19 12L12 19" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        <div className="rule r-line mb-10" />

        {/* Cards grid */}
        <div className="svc-grid grid grid-cols-1 md:grid-cols-3 gap-6">
          {CARDS.map((c, i) => (
            <div key={i} className="svc-card group border border-[var(--rule)] p-5 flex flex-col transition-all duration-500 hover:border-[var(--terra)]/30 hover:bg-[var(--cream-light)]">
              {/* Image */}
              <div className="relative overflow-hidden aspect-[16/11] mb-6">
                <div className="svc-img-inner absolute inset-0 scale-[1.1]">
                  <img src={c.img} alt={c.title} className="w-full h-full object-cover img-bw" />
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 flex flex-col">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="font-serif text-[clamp(1.3rem,2vw,1.7rem)] leading-[1.15] whitespace-pre-line group-hover:text-[var(--terra)] transition-colors duration-500">
                    {c.title}
                  </h3>
                  <span className="font-serif text-4xl text-[var(--rule)] group-hover:text-[var(--terra)]/20 transition-colors shrink-0 ml-3">
                    {c.num}
                  </span>
                </div>

                <p className="font-sans text-[11px] leading-[1.8] text-[var(--ink-soft)] mb-6">
                  {c.desc}
                </p>

                <div className="mt-auto flex items-center justify-between">
                  <span className="font-sans text-[10px] uppercase tracking-[0.12em] text-[var(--ink-soft)] group-hover:text-[var(--terra)] transition-colors">
                    Learn more
                  </span>
                  <div className="arr-btn" style={{ width: 36, height: 36 }}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-3.5 h-3.5">
                      <path d="M7 17L17 7M17 7H7M17 7V17" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-8 md:px-14 mt-16">
        <div className="rule r-line" />
      </div>
    </section>
  );
}
