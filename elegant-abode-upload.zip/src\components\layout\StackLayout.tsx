import { useScroll, useTransform, motion } from "framer-motion";
import { useRef, type ReactNode } from "react";

/**
 * StackLayout — a wrapper component that creates a 3D Z-axis stacking effect.
 * As the user scrolls past this section, it pins to the top, scales down into the background,
 * and darkens, allowing the next section to slide over it.
 */
export function StackLayout({
  children,
  className,
  index,
  total,
}: {
  children: ReactNode;
  className?: string;
  index: number;
  total: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  // Calculate stacking effect based on scroll position
  // It only scales down and darkens after it reaches the top
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.92]);
  const opacity = useTransform(scrollYProgress, [0, 1], [1, 0.4]);
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "5%"]);

  return (
    <div ref={ref} className={`relative min-h-[100svh] ${className ?? ""}`} style={{ zIndex: index }}>
      <div className="sticky top-0 h-[100svh] w-full overflow-hidden">
        <motion.div
          style={{ scale, opacity, y, transformOrigin: "top" }}
          className="w-full h-full"
        >
          {children}
        </motion.div>
      </div>
    </div>
  );
}
