export function Footer() {
  return (
    <footer className="bg-[var(--ink)] text-[var(--cream)]">
      {/* CTA Band */}
      <div className="max-w-[1400px] mx-auto px-8 md:px-14 py-24 md:py-36">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
          <div className="md:col-span-7">
            <span className="font-sans text-[10px] uppercase tracking-[0.18em] text-[var(--cream)]/40 block mb-6">
              Get in Touch
            </span>
            <h2 className="font-serif text-[clamp(2.5rem,6vw,5.5rem)] leading-[0.95] mb-8">
              Let's Build<br />
              <em className="italic text-[var(--terra)]">Green</em> Together.
            </h2>
            <p className="font-sans text-[12px] leading-[1.9] text-[var(--cream)]/45 max-w-[380px] mb-10">
              Ready to transform your vision into a sustainable reality? Share your project details and let's start creating.
            </p>
            <div className="flex items-center gap-5">
              <div className="arr-btn-lg" style={{ width: 56, height: 56 }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-5 h-5">
                  <path d="M7 17L17 7M17 7H7M17 7V17" />
                </svg>
              </div>
              <span className="font-sans text-[10px] uppercase tracking-[0.12em] text-[var(--cream)]/50">
                Start a project
              </span>
            </div>
          </div>

          {/* Contact Form */}
          <div className="md:col-span-5 flex flex-col justify-center">
            <form className="flex flex-col gap-8" onSubmit={(e) => e.preventDefault()}>
              <div>
                <label className="block font-sans text-[9px] uppercase tracking-[0.2em] text-[var(--cream)]/35 mb-3">Name</label>
                <input type="text" placeholder="Your name"
                  className="w-full bg-transparent border-b border-[var(--cream)]/12 pb-3 text-[var(--cream)] font-serif text-lg focus:outline-none focus:border-[var(--terra)] transition-colors placeholder:text-[var(--cream)]/18" />
              </div>
              <div>
                <label className="block font-sans text-[9px] uppercase tracking-[0.2em] text-[var(--cream)]/35 mb-3">Email</label>
                <input type="email" placeholder="your@email.com"
                  className="w-full bg-transparent border-b border-[var(--cream)]/12 pb-3 text-[var(--cream)] font-serif text-lg focus:outline-none focus:border-[var(--terra)] transition-colors placeholder:text-[var(--cream)]/18" />
              </div>
              <div>
                <label className="block font-sans text-[9px] uppercase tracking-[0.2em] text-[var(--cream)]/35 mb-3">Message</label>
                <textarea rows={2} placeholder="Tell us about your vision..."
                  className="w-full bg-transparent border-b border-[var(--cream)]/12 pb-3 text-[var(--cream)] font-serif text-lg focus:outline-none focus:border-[var(--terra)] transition-colors resize-none placeholder:text-[var(--cream)]/18" />
              </div>
              <button type="submit"
                className="mt-2 self-start group inline-flex items-center gap-3 border border-[var(--cream)]/15 px-8 py-4 text-[10px] uppercase tracking-[0.15em] font-sans hover:bg-[var(--terra)] hover:border-[var(--terra)] transition-all duration-500">
                <span>Send</span>
                <svg className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M5 12H19M19 12L12 5M19 12L12 19" />
                </svg>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Footer links */}
      <div className="border-t border-[var(--cream)]/8">
        <div className="max-w-[1400px] mx-auto px-8 md:px-14 py-14 grid grid-cols-2 md:grid-cols-4 gap-10">
          <div>
            <span className="font-serif text-2xl font-semibold block mb-4 tracking-wide">Terraforma</span>
            <p className="font-sans text-[11px] text-[var(--cream)]/35 leading-relaxed max-w-[200px]">
              Architecture for a greener tomorrow.
            </p>
          </div>
          <div>
            <div className="font-sans text-[9px] uppercase tracking-[0.2em] text-[var(--cream)]/30 mb-5">Navigate</div>
            {['Home', 'About', 'Services', 'Projects', 'Blog'].map(l => (
              <a key={l} href="#" className="block font-sans text-[12px] text-[var(--cream)]/45 hover:text-[var(--terra)] transition-colors mb-2.5">{l}</a>
            ))}
          </div>
          <div>
            <div className="font-sans text-[9px] uppercase tracking-[0.2em] text-[var(--cream)]/30 mb-5">Services</div>
            {['Green Design', 'Eco Villas', 'Masterplanning', 'Consulting'].map(l => (
              <a key={l} href="#" className="block font-sans text-[12px] text-[var(--cream)]/45 hover:text-[var(--terra)] transition-colors mb-2.5">{l}</a>
            ))}
          </div>
          <div>
            <div className="font-sans text-[9px] uppercase tracking-[0.2em] text-[var(--cream)]/30 mb-5">Connect</div>
            {['Instagram', 'LinkedIn', 'Behance', 'Twitter'].map(l => (
              <a key={l} href="#" className="block font-sans text-[12px] text-[var(--cream)]/45 hover:text-[var(--terra)] transition-colors mb-2.5">{l}</a>
            ))}
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-[var(--cream)]/6">
        <div className="max-w-[1400px] mx-auto px-8 md:px-14 py-5 flex items-center justify-between">
          <span className="font-sans text-[9px] uppercase tracking-[0.15em] text-[var(--cream)]/20">
            © 2024 Terraforma — All Rights Reserved
          </span>
          <div className="flex gap-5">
            <a href="#" className="font-sans text-[9px] uppercase tracking-[0.12em] text-[var(--cream)]/20 hover:text-[var(--cream)]/50 transition-colors">Privacy</a>
            <a href="#" className="font-sans text-[9px] uppercase tracking-[0.12em] text-[var(--cream)]/20 hover:text-[var(--cream)]/50 transition-colors">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
