import { useEffect, useRef } from 'react';

export function Cursor() {
  const ref = useRef<HTMLDivElement>(null);
  const pos = useRef({ x: 0, y: 0 });
  const target = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const move = (e: MouseEvent) => { target.current = { x: e.clientX, y: e.clientY }; };
    const enter = () => el.classList.add('is-hover');
    const leave = () => el.classList.remove('is-hover');
    window.addEventListener('mousemove', move);

    const attach = () => {
      document.querySelectorAll('a,button,.arr-btn,.arr-btn-lg,[data-cursor]').forEach((n) => {
        n.addEventListener('mouseenter', enter);
        n.addEventListener('mouseleave', leave);
      });
    };
    attach();
    const obs = new MutationObserver(attach);
    obs.observe(document.body, { childList: true, subtree: true });

    let raf: number;
    const loop = () => {
      pos.current.x += (target.current.x - pos.current.x) * 0.1;
      pos.current.y += (target.current.y - pos.current.y) * 0.1;
      el.style.left = `${pos.current.x}px`;
      el.style.top = `${pos.current.y}px`;
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => { window.removeEventListener('mousemove', move); cancelAnimationFrame(raf); obs.disconnect(); };
  }, []);

  return <div ref={ref} className="cursor-main hidden md:block" />;
}
