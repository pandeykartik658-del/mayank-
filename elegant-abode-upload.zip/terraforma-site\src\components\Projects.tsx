import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const WORKS = [
  {
    title: 'Forest Canopy Retreat',
    location: 'Bali, Indonesia',
    year: '2024',
    cat: 'Residential',
    img: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=1200&q=85&auto=format',
  },
  {
    title: 'Timber Frame Pavilion',
    location: 'Kyoto, Japan',
    year: '2023',
    cat: 'Cultural',
    img: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200&q=85&auto=format',
  },
  {
    title: 'Alpine Earth House',
    location: 'Swiss Alps',
    year: '2024',
    cat: 'Residential',
    img: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&q=85&auto=format',
  },
];

export function Projects() {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Each project row
      gsap.utils.toArray<HTMLElement>('.proj-row').forEach((el) => {
        gsap.fromTo(el, { opacity: 0, y: 60 }, {
          opacity: 1, y: 0, duration: 1.1, ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 82%' },
        });
      });

      // Image parallax
      gsap.utils.toArray<HTMLElement>('.proj-img-inner').forEach((el) => {
        gsap.to(el, {
          yPercent: -14, ease: 'none',
          scrollTrigger: { trigger: el.closest('.proj-row') || el, start: 'top bottom', end: 'bottom top', scrub: 1.5 },
        });
      });
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={ref} id="projects" className="py-20 md:py-32">
      <div className="max-w-[1400px] mx-auto px-8 md:px-14">
        {/* Section header */}
        <div className="flex items-center gap-3 mb-3 r-fade">
          <span className="font-sans text-[10px] uppercase tracking-[0.18em] text-[var(--ink-soft)]">
            Featured Work
          </span>
        </div>

        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14">
          <h2 className="r-up font-serif text-[clamp(2rem,4.5vw,3.8rem)] leading-[1.1]">
            Selected Projects
          </h2>
          <a href="#" className="r-up font-sans text-[10px] uppercase tracking-[0.12em] text-[var(--ink-soft)] hover:text-[var(--terra)] transition-colors">
            View all →
          </a>
        </div>

        <div className="rule r-line mb-0" />

        {/* Project rows */}
        {WORKS.map((p, i) => (
          <div key={i} className="proj-row group border-b border-[var(--rule)]">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-10 py-10 md:py-16">
              {/* Number + Title */}
              <div className="md:col-span-4 flex flex-col justify-center">
                <span className="font-serif text-6xl md:text-7xl text-[var(--rule)] group-hover:text-[var(--terra)]/20 transition-colors duration-700 mb-4">
                  0{i + 1}
                </span>
                <h3 className="font-serif text-2xl md:text-3xl leading-[1.1] group-hover:text-[var(--terra)] transition-colors duration-500">
                  {p.title}
                </h3>
                <p className="font-sans text-[10px] uppercase tracking-[0.12em] text-[var(--ink-soft)] mt-3">
                  {p.location} · {p.year}
                </p>
              </div>

              {/* Image */}
              <div className={`md:col-span-6 ${i % 2 === 1 ? 'md:col-start-1 md:row-start-1' : 'md:col-start-5'}`}>
                <div className="relative overflow-hidden aspect-[16/10]">
                  <div className="proj-img-inner absolute inset-0 scale-[1.12]">
                    <img src={p.img} alt={p.title}
                      className="w-full h-full object-cover img-bw transition-transform duration-700 group-hover:scale-105" />
                  </div>
                  {/* Hover overlay */}
                  <div className="absolute inset-0 bg-[var(--ink)]/0 group-hover:bg-[var(--ink)]/10 transition-all duration-500" />
                </div>
              </div>

              {/* Arrow + Category */}
              <div className="md:col-span-2 flex flex-col items-end justify-between">
                <span className="font-sans text-[10px] uppercase tracking-[0.12em] text-[var(--ink-soft)]">
                  {p.cat}
                </span>
                <div className="arr-btn opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M7 17L17 7M17 7H7M17 7V17" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
