import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useState } from "react";

export function TopBar() {
  const [dark, setDark] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { scrollY } = useScroll();
  const padY = useTransform(scrollY, [0, 200], [24, 14]);

  useEffect(() => {
    const onScroll = () => {
      const sections = document.querySelectorAll<HTMLElement>("section");
      const probeY = 40;
      let found = false;
      sections.forEach((s) => {
        const r = s.getBoundingClientRect();
        if (r.top <= probeY && r.bottom >= probeY) {
          if (s.classList.contains("bg-ink")) {
            found = true;
          }
        }
      });
      setDark(found);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const color = dark ? "text-paper" : "text-ink";
  const borderColor = dark ? "border-paper/40" : "border-ink/40";

  return (
    <>
      <motion.header
        style={{ paddingTop: padY, paddingBottom: padY }}
        className="fixed top-0 left-0 right-0 z-50 pointer-events-none transition-colors duration-500"
      >
        <div className="mx-auto px-6 md:px-12 flex items-center justify-between pointer-events-auto">
          {/* Logo */}
          <a href="/" className={`font-display text-xl md:text-2xl tracking-[0.2em] ${color} transition-colors duration-500`}>
            LAAV<sup className="text-[9px] font-sans ml-0.5">®</sup>
          </a>

          {/* Desktop Nav */}
          <nav className={`hidden md:flex items-center gap-4 text-[11px] uppercase tracking-[0.2em] ${color} transition-colors duration-500`}>
            <a href="#works" className={`border ${borderColor} rounded-full px-5 py-2 hover:opacity-60 transition-all duration-300`}>Projects</a>
            <a href="#about" className={`border ${borderColor} rounded-full px-5 py-2 hover:opacity-60 transition-all duration-300`}>About</a>
            <a href="#contact" className={`border ${borderColor} rounded-full px-5 py-2 hover:opacity-60 transition-all duration-300`}>Contact</a>
          </nav>

          {/* Desktop CTA */}
          <a href="#contact" className={`hidden md:block text-[11px] uppercase tracking-[0.2em] ${color} transition-colors duration-500 hover:opacity-60 border ${borderColor} rounded-full px-5 py-2`}>
            Let's Talk
          </a>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className={`md:hidden flex flex-col gap-1.5 ${color} transition-colors duration-500`}
            aria-label="Menu"
          >
            <span className={`block w-6 h-px bg-current transition-transform duration-300 ${menuOpen ? "rotate-45 translate-y-[4px]" : ""}`} />
            <span className={`block w-6 h-px bg-current transition-opacity duration-300 ${menuOpen ? "opacity-0" : ""}`} />
            <span className={`block w-6 h-px bg-current transition-transform duration-300 ${menuOpen ? "-rotate-45 -translate-y-[4px]" : ""}`} />
          </button>
        </div>
      </motion.header>

      {/* Mobile Menu Overlay */}
      {menuOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-40 bg-ink/95 backdrop-blur-md flex flex-col items-center justify-center gap-8"
          onClick={() => setMenuOpen(false)}
        >
          <a href="#works" className="font-display text-3xl text-paper tracking-[0.2em] uppercase hover:text-clay transition-colors">Projects</a>
          <a href="#about" className="font-display text-3xl text-paper tracking-[0.2em] uppercase hover:text-clay transition-colors">About</a>
          <a href="#contact" className="font-display text-3xl text-paper tracking-[0.2em] uppercase hover:text-clay transition-colors">Contact</a>
          <div className="mt-8 h-px w-16 bg-paper/20" />
          <a href="#contact" className="text-sm text-paper/60 tracking-[0.2em] uppercase hover:text-paper transition-colors">Let's Talk</a>
        </motion.div>
      )}
    </>
  );
}
