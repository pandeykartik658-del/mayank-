import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const PROJECTS = [
  { img: "https://images.unsplash.com/photo-1518005020951-eccb494ad742?w=800&q=80", name: "Landscape Pavilion", loc: "Joshua Tree" },
  { img: "https://images.unsplash.com/photo-1448630360428-65456885c650?w=1000&q=80", name: "Underground House", loc: "Swiss Alps" },
  { img: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1200&q=80", name: "Glass Ceiling Structure", loc: "Oslo" },
  { img: "https://images.unsplash.com/photo-1487958449943-2429e5be8624?w=1000&q=80", name: "Modernist Villa", loc: "Copenhagen" },
  { img: "https://images.unsplash.com/photo-1513694203232-719a280e022f?w=1000&q=80", name: "Concrete Minimal", loc: "Berlin" },
  { img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1000&q=80", name: "Stone Retreat", loc: "Kyoto" },
];

export function OtherProjects() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-15% 0px" });

  return (
    <section ref={ref} id="other-projects" className="relative bg-paper text-ink overflow-hidden">
      {/* Section Header */}
      <div className="border-t border-b border-ink/15 px-6 md:px-12 py-5 flex items-center justify-between pointer-events-none">
        <span className="text-[11px] uppercase tracking-[0.25em] text-ink/50">04 — Other Projects</span>
        <span className="text-[11px] uppercase tracking-[0.25em] text-ink/50">Gallery</span>
      </div>

      <div className="px-6 md:px-12 py-32 md:py-48 max-w-[1600px] mx-auto">
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-24 items-center mb-24 md:mb-32">
          {/* Title Section (Left) */}
          <div className="flex flex-col gap-8 md:pt-12">
            <h2 className="font-display text-4xl md:text-5xl lg:text-[56px] leading-[1.1] uppercase tracking-[0.05em] max-w-4xl">
              EACH PROJECT IS A<br />
              GEOMETRICAL TRANSLATION<br />
              OF THE LANDSCAPE
            </h2>
            <p className="text-base font-light leading-[1.8] text-ink/65 max-w-xl">
              A careful reading of the landscape around a building project can add infinite variations of volumes. 
              The careful reading, yes — as an actual book. A volume of information extracted by the 
              landscape that is directly translated into design is among the top priorities.
            </p>
            <a href="#" className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.25em] border-b border-ink/30 pb-1 w-max hover:border-ink transition-colors mt-4">
              SEE GALLERY <span aria-hidden>→</span>
            </a>
          </div>

          {/* Single Image Section (Right) */}
          <div className="w-full">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-10% 0px" }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="relative group overflow-hidden w-full aspect-[4/5] bg-ink/5"
            >
              <img
                src="https://images.unsplash.com/photo-1518005020951-eccb494ad742?w=1200&q=80"
                alt="Landscape Translation"
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
              />
            </motion.div>
          </div>
        </div>

        {/* Large Logo Bottom Right */}
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.4 }}
          className="mt-32 md:mt-48 flex justify-end"
        >
          <span className="font-display text-[12vw] md:text-[8vw] leading-none tracking-[0.05em] text-ink">
            LAAV<sup className="text-[3vw] md:text-[2vw]">®</sup>
          </span>
        </motion.div>

      </div>
    </section>
  );
}
