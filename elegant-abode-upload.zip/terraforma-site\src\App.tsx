import { useEffect, useRef } from 'react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Cursor } from './components/Cursor';
import { Nav } from './components/Nav';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Projects } from './components/Projects';
import { Footer } from './components/Footer';
import './index.css';

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.06, smoothWheel: true });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add((t) => lenis.raf(t * 1000));
    gsap.ticker.lagSmoothing(0);

    // Global reveal-up
    gsap.utils.toArray<HTMLElement>('.r-up').forEach((el) => {
      gsap.to(el, {
        opacity: 1, y: 0, duration: 1.1, ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 88%' },
      });
    });

    // Global line-draw
    gsap.utils.toArray<HTMLElement>('.r-line').forEach((el) => {
      gsap.to(el, {
        scaleX: 1, duration: 1.3, ease: 'power2.inOut',
        scrollTrigger: { trigger: el, start: 'top 92%' },
      });
    });

    // Global fade
    gsap.utils.toArray<HTMLElement>('.r-fade').forEach((el) => {
      gsap.to(el, {
        opacity: 1, duration: 1, ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 88%' },
      });
    });

    return () => { lenis.destroy(); ScrollTrigger.getAll().forEach(t => t.kill()); };
  }, []);

  return (
    <div ref={wrapRef} className="grain">
      <Cursor />
      <Nav />
      <Hero />
      <About />
      <Services />
      <Projects />
      <Footer />
    </div>
  );
}
