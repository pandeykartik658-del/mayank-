import { useState, useEffect } from 'react';

export function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', fn, { passive: true });
    return () => window.removeEventListener('scroll', fn);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-700 ${scrolled ? 'py-3 bg-[var(--cream)]/85 backdrop-blur-md shadow-[0_1px_0_var(--rule)]' : 'py-5'}`}>
      <div className="max-w-[1400px] mx-auto px-8 md:px-14 flex items-center justify-between">
        {/* Nav links */}
        <nav className="hidden md:flex items-center gap-5">
          {['About us', 'Services', 'Insights', 'Projects', 'Blog'].map((item) => (
            <a key={item} href={`#${item.toLowerCase().replace(/\s/g, '')}`} className="nav-link">
              {item}
            </a>
          ))}
        </nav>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-5">
          <span className="font-sans text-[11px] tracking-[0.06em] text-[var(--ink-soft)] uppercase">
            Talk your plan
          </span>
          <div className="arr-btn-lg">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M7 17L17 7M17 7H7M17 7V17" />
            </svg>
          </div>
        </div>

        {/* Mobile: logo + burger */}
        <span className="md:hidden font-serif text-2xl font-semibold tracking-wide">Terraforma</span>
        <button className="md:hidden flex flex-col gap-[5px] w-6">
          <span className="block h-[1.5px] w-full bg-[var(--ink)]" />
          <span className="block h-[1.5px] w-full bg-[var(--ink)]" />
        </button>
      </div>
    </header>
  );
}
