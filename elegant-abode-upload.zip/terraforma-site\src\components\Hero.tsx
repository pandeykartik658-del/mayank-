import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function Hero() {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title words stagger
      const words = document.querySelectorAll('.hw');
      gsap.fromTo(words, { y: 140, opacity: 0 }, {
        y: 0, opacity: 1, duration: 1.6, stagger: 0.07,
        ease: 'power4.out', delay: 0.3,
      });

      // Hero images
      gsap.fromTo('.hero-img', { scale: 1.2, opacity: 0 }, {
        scale: 1, opacity: 1, duration: 1.4, stagger: 0.2,
        ease: 'power3.out', delay: 0.8,
      });

      // Meta row
      gsap.fromTo('.hero-meta', { opacity: 0, y: 15 }, {
        opacity: 1, y: 0, duration: 0.8, stagger: 0.08,
        ease: 'power2.out', delay: 1.4,
      });

      // Parallax on hero images
      gsap.utils.toArray<HTMLElement>('.hero-parallax').forEach((el) => {
        gsap.to(el, {
          yPercent: -18, ease: 'none',
          scrollTrigger: { trigger: ref.current, start: 'top top', end: 'bottom top', scrub: 1.2 },
        });
      });
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={ref} className="relative min-h-screen pt-20 md:pt-24 pb-0 overflow-hidden">
      {/* Top rule */}
      <div className="max-w-[1400px] mx-auto px-8 md:px-14">
        <div className="rule r-line mb-6" />
      </div>

      {/* Main hero grid */}
      <div className="max-w-[1400px] mx-auto px-8 md:px-14 relative">
        <div className="grid grid-cols-12 gap-4">

          {/* Title block — spans left 8 cols */}
          <div className="col-span-12 md:col-span-8 relative z-10">
            <h1 className="font-serif leading-[0.92] tracking-[-0.02em]" style={{ fontSize: 'clamp(3.2rem, 9.5vw, 9rem)' }}>
              <span className="hw inline-block">Sustainable</span>
              <br />
              <span className="hw inline-block italic font-light">Living</span>
              <span className="hw inline-block mx-[0.15em] w-[1.2em] h-[2px] bg-[var(--ink)] align-middle translate-y-[-0.15em]" />
              <span className="hw inline-block italic">Spaces</span>
            </h1>
          </div>

          {/* Right column — CTA + small image */}
          <div className="col-span-12 md:col-span-4 flex flex-col items-end justify-between gap-6 md:pt-4">
            {/* Talk your plan + arrow */}
            <div className="flex items-center gap-4 hero-meta">
              <span className="font-sans text-[10px] uppercase tracking-[0.12em] text-[var(--ink-soft)]">
                Talk your plan
              </span>
              <div className="arr-btn-lg" style={{ width: 48, height: 48 }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-4 h-4">
                  <path d="M7 17L17 7M17 7H7M17 7V17" />
                </svg>
              </div>
            </div>

            {/* Small thumbnail images */}
            <div className="flex gap-2 hero-img">
              <div className="w-[90px] h-[65px] overflow-hidden">
                <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=300&q=80&auto=format"
                  alt="" className="w-full h-full object-cover" />
              </div>
              <div className="w-[90px] h-[65px] overflow-hidden">
                <img src="https://images.unsplash.com/photo-1487958449943-2429e5be8624?w=300&q=80&auto=format"
                  alt="" className="w-full h-full object-cover" />
              </div>
            </div>

            {/* Right-side description */}
            <p className="font-sans text-[11px] leading-[1.7] text-[var(--ink-soft)] max-w-[220px] text-right hero-meta">
              Creating timeless spaces with minimal environmental impact. Transforming the way we live, one green space at a time.
            </p>
          </div>
        </div>

        {/* Hero large image */}
        <div className="mt-8 relative overflow-hidden h-[55vh] md:h-[60vh] hero-img">
          <div className="hero-parallax absolute inset-0 scale-[1.15]">
            <img
              src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1800&q=85&auto=format"
              alt="Sustainable modern home"
              className="w-full h-full object-cover object-center"
            />
          </div>
        </div>

        {/* Bottom metadata row */}
        <div className="grid grid-cols-3 border-t border-b border-[var(--rule)] mt-0">
          <div className="py-5 px-2 hero-meta">
            <span className="font-sans text-[10px] uppercase tracking-[0.1em] text-[var(--ink-soft)]">Eco Retreat, Villas</span>
          </div>
          <div className="py-5 px-2 text-center border-l border-r border-[var(--rule)] hero-meta">
            <span className="font-serif text-lg">2023</span>
          </div>
          <div className="py-5 px-2 text-right hero-meta">
            <span className="font-sans text-[10px] uppercase tracking-[0.1em] text-[var(--ink-soft)]">Luxury Living</span>
          </div>
        </div>
      </div>
    </section>
  );
}
