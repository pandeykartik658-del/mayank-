import { motion, useMotionValue, useSpring, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

type CursorState = "default" | "hover" | "view" | "play" | "drag" | "explore" | "hidden";

const CURSOR_LABELS: Record<string, string> = {
  view: "View",
  play: "Play",
  drag: "Drag",
  explore: "Explore",
};

export function Cursor() {
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const sx = useSpring(x, { stiffness: 380, damping: 32, mass: 0.4 });
  const sy = useSpring(y, { stiffness: 380, damping: 32, mass: 0.4 });
  const [state, setState] = useState<CursorState>("default");
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!window.matchMedia("(pointer: fine)").matches) return;
    setEnabled(true);
    document.documentElement.classList.add("cursor-custom");

    const move = (e: MouseEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
    };

    const over = (e: MouseEvent) => {
      const t = e.target as HTMLElement;

      // Check for explicit data-cursor attribute first
      const cursorEl = t.closest("[data-cursor]") as HTMLElement | null;
      if (cursorEl) {
        const val = cursorEl.getAttribute("data-cursor") as CursorState;
        if (val === "hidden") {
          setState("hidden");
        } else if (val in CURSOR_LABELS) {
          setState(val as CursorState);
        } else if (val === "hover") {
          setState("hover");
        } else {
          setState("hover");
        }
        return;
      }

      // Fallback: check for interactive elements
      if (t.closest("a,button,[role=button]")) {
        setState("hover");
        return;
      }

      setState("default");
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("mouseover", over);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseover", over);
      document.documentElement.classList.remove("cursor-custom");
    };
  }, [x, y]);

  if (!enabled) return null;

  const isLabeled = state in CURSOR_LABELS;
  const isHover = state === "hover";
  const isHidden = state === "hidden";
  const isDefault = state === "default";

  const size = isLabeled ? 80 : isHover ? 48 : 12;

  return (
    <motion.div
      style={{ x: sx, y: sy }}
      className="pointer-events-none fixed top-0 left-0 z-[70]"
      animate={{ opacity: isHidden ? 0 : 1 }}
      transition={{ duration: 0.3 }}
    >
      <motion.div
        animate={{
          width: size,
          height: size,
          borderRadius: isLabeled ? 40 : 100,
        }}
        transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
        className="-translate-x-1/2 -translate-y-1/2 flex items-center justify-center"
        style={{
          background: isLabeled
            ? "rgba(180, 120, 60, 0.9)"
            : isHover
              ? "rgba(180, 120, 60, 0.12)"
              : "transparent",
          border: isDefault
            ? "1px solid var(--paper)"
            : isHover
              ? "1px solid rgba(180, 120, 60, 0.3)"
              : "none",
          mixBlendMode: isLabeled ? "normal" : "difference",
          backdropFilter: isLabeled ? "blur(8px)" : "none",
        }}
      >
        {/* Default inner dot */}
        <AnimatePresence mode="wait">
          {isDefault && (
            <motion.span
              key="dot"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              className="block w-1 h-1 rounded-full bg-clay"
            />
          )}
          {isLabeled && (
            <motion.span
              key={state}
              initial={{ opacity: 0, scale: 0.7, y: 4 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.7, y: -4 }}
              transition={{ duration: 0.25 }}
              className="label-meta text-paper text-[9px] tracking-[0.2em]"
            >
              {CURSOR_LABELS[state]}
            </motion.span>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}
