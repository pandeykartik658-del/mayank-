import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { MagneticButton } from "@/components/motion/MagneticButton";

export function ClosingFrame() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-15% 0px" });

  return (
    <section ref={ref} id="contact" className="relative bg-ink text-paper overflow-hidden">
      {/* Section Header */}
      <div className="border-t border-b border-paper/10 px-6 md:px-12 py-5 flex items-center justify-between">
        <span className="text-[11px] uppercase tracking-[0.25em] text-paper/40">06 — Contact</span>
        <span className="text-[11px] uppercase tracking-[0.25em] text-paper/40">Get in Touch</span>
      </div>

      {/* Main Content */}
      <div className="px-6 md:px-12 py-32 md:py-40 max-w-[1600px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-24">
          
          {/* Left: Big CTA */}
          <div className="flex flex-col justify-between">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-15% 0px" }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            >
              <h2 className="font-display text-5xl md:text-7xl lg:text-[100px] leading-[0.9] tracking-[0.02em] uppercase mb-12">
                LET'S BUILD<br/>SOMETHING<br/>TOGETHER.
              </h2>
              <div className="h-px w-16 bg-clay mb-10" />
              <p className="text-lg md:text-xl font-light leading-relaxed text-paper/60 max-w-md">
                Whether it's a private residence, a public institution, or a masterplan — we'd love to hear about your project.
              </p>
            </motion.div>
          </div>

          {/* Right: Contact Form */}
          <div className="flex flex-col justify-end">
            <motion.form
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-15% 0px" }}
              transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col gap-8 w-full max-w-lg ml-auto"
              onSubmit={(e) => e.preventDefault()}
            >
              <div className="flex flex-col gap-2">
                <label className="text-[10px] uppercase tracking-[0.25em] text-paper/40">Name</label>
                <input 
                  type="text" 
                  className="w-full bg-transparent border-b border-paper/20 pb-3 text-paper focus:outline-none focus:border-paper transition-colors rounded-none"
                  placeholder="Your Name"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-[10px] uppercase tracking-[0.25em] text-paper/40">Email</label>
                <input 
                  type="email" 
                  className="w-full bg-transparent border-b border-paper/20 pb-3 text-paper focus:outline-none focus:border-paper transition-colors rounded-none"
                  placeholder="Your Email"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-[10px] uppercase tracking-[0.25em] text-paper/40">Message</label>
                <textarea 
                  rows={4}
                  className="w-full bg-transparent border-b border-paper/20 pb-3 text-paper focus:outline-none focus:border-paper transition-colors resize-none rounded-none"
                  placeholder="Tell us about your project..."
                />
              </div>
              
              <button
                type="submit"
                className="mt-4 group inline-flex items-center justify-center gap-4 text-[11px] uppercase tracking-[0.25em] border border-paper/30 px-8 py-5 hover:bg-paper hover:text-ink transition-all duration-500 w-max"
              >
                <span>Send Message</span>
                <span aria-hidden className="inline-block transition-transform group-hover:translate-x-2">
                  →
                </span>
              </button>
            </motion.form>
          </div>

        </div>
      </div>

      {/* Footer Bar */}
      <div className="border-t border-paper/8 px-6 md:px-12 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="font-display text-sm tracking-[0.15em] text-paper/30">
          LAAV<sup className="text-[8px]">®</sup> Architecture
        </div>
        <div className="text-[10px] uppercase tracking-[0.25em] text-paper/20">
          © 2024 — All Rights Reserved
        </div>
      </div>
    </section>
  );
}
