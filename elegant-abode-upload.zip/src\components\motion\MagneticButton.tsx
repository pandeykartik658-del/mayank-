import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useRef, type ReactNode, type MouseEvent } from "react";

export function MagneticButton({
  children,
  className,
  href,
  strength = 0.35,
  innerStrength = 0.15,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  href?: string;
  strength?: number;
  innerStrength?: number;
  onClick?: () => void;
}) {
  const ref = useRef<HTMLAnchorElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 200, damping: 18, mass: 0.6 });
  const sy = useSpring(y, { stiffness: 200, damping: 18, mass: 0.6 });

  // Inner text moves at a different rate for depth
  const innerX = useTransform(sx, (v) => v * (innerStrength / strength) * 1.6);
  const innerY = useTransform(sy, (v) => v * (innerStrength / strength) * 1.6);

  // Glow position
  const glowX = useTransform(sx, (v) => 50 + v * 2);
  const glowY = useTransform(sy, (v) => 50 + v * 2);

  const move = (e: MouseEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    x.set((e.clientX - r.left - r.width / 2) * strength);
    y.set((e.clientY - r.top - r.height / 2) * strength);
  };
  const reset = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.a
      ref={ref}
      href={href}
      onClick={onClick}
      onMouseMove={move}
      onMouseLeave={reset}
      style={{ x: sx, y: sy }}
      className={`${className ?? ""} relative overflow-hidden`}
      data-cursor="hover"
      whileHover="hovered"
    >
      {/* Radial glow that follows the mouse */}
      <motion.div
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{
          background: useTransform(
            [glowX, glowY],
            ([gx, gy]) =>
              `radial-gradient(circle at ${gx}% ${gy}%, rgba(180,120,60,0.15) 0%, transparent 60%)`
          ),
        }}
        variants={{
          hovered: { opacity: 1 },
        }}
        initial={{ opacity: 0 }}
      />

      {/* Inner content with independent displacement */}
      <motion.span
        style={{ x: innerX, y: innerY }}
        className="relative z-10 inline-flex items-center gap-4"
      >
        {children}
      </motion.span>
    </motion.a>
  );
}
