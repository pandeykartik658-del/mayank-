import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";
import { useRef, useState, useEffect } from "react";

const PROJECTS = [
  {
    no: "014",
    name: "MERIDIAN TOWER",
    typology: "Office",
    city: "Singapore",
    year: "2024",
    stats: "42 floors  ·  78,000 m²  ·  Hesse Capital",
    desc: "A vertical district carved by light. Triple-skin façade reduces solar load by 38% while opening every floor plate to the South China Sea.",
    img: "https://images.unsplash.com/photo-1545153996-ec5f7b3b1c2c?w=2400&q=80&auto=format&fit=crop",
  },
  {
    no: "013",
    name: "HALDEN EXCHANGE",
    typology: "Civic",
    city: "Oslo",
    year: "2024",
    stats: "21,400 m²  ·  Oslo Municipality",
    desc: "A new courthouse rendered as a single quiet stone — a public room held inside a colonnade of weathered oak.",
    img: "https://images.unsplash.com/photo-1486325212027-8081e485255e?w=2400&q=80&auto=format&fit=crop",
  },
  {
    no: "012",
    name: "NORTH QUAY",
    typology: "Masterplan",
    city: "Rotterdam",
    year: "2023",
    stats: "62 ha  ·  Port of Rotterdam",
    desc: "A working harbour reimagined as a continuous civic ground. Twelve blocks, one promenade, a city that meets the water without raising its voice.",
    img: "https://images.unsplash.com/photo-1464146072230-91cabc968266?w=2400&q=80&auto=format&fit=crop",
  },
];

export function FeaturedProjects() {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const dialLength = useTransform(scrollYProgress, [0, 1], [0, 1]);

  useEffect(() => {
    const unsub = scrollYProgress.on("change", (v) => {
      const i = Math.min(PROJECTS.length - 1, Math.floor(v * PROJECTS.length * 0.999));
      setActive(i);
    });
    return () => unsub();
  }, [scrollYProgress]);

  const p = PROJECTS[active];

  return (
    <section
      id="works"
      ref={ref}
      className="relative bg-ink text-paper"
      style={{ height: `${PROJECTS.length * 100}vh` }}
    >
      {/* Section Label Bar */}
      <div className="sticky top-[80px] z-30 bg-ink">
        <div className="border-t border-b border-paper/15 px-6 md:px-12 py-5 flex items-center justify-between">
          <span className="text-[11px] uppercase tracking-[0.25em] text-paper/50">02 — Selected Works</span>
          <span className="text-[11px] uppercase tracking-[0.25em] text-paper/50">{PROJECTS.length} Projects</span>
        </div>
      </div>

      <div className="sticky top-[140px] h-[calc(100svh-140px)] w-full flex flex-col overflow-hidden">
        
        {/* Circular dial */}
        <div className="absolute top-6 right-6 md:right-12 z-20 pointer-events-none">
          <div className="relative w-14 h-14">
            <svg viewBox="0 0 64 64" className="w-full h-full -rotate-90">
              <circle cx="32" cy="32" r="28" stroke="rgba(239,236,228,0.12)" strokeWidth="1" fill="none" />
              <motion.circle
                cx="32" cy="32" r="28"
                stroke="var(--clay)" strokeWidth="1.5" fill="none"
                style={{ pathLength: dialLength }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center text-[11px] uppercase tracking-[0.15em] text-paper">
              {String(active + 1).padStart(2, "0")}
            </div>
          </div>
        </div>

        {/* Split Layout */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 px-6 md:px-12 gap-8 md:gap-16 relative z-10 h-full">
          
          {/* Left: Project Info */}
          <div className="flex flex-col justify-center order-2 md:order-1 h-full py-12">
            <AnimatePresence mode="wait">
              <motion.div
                key={p.no}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                className="max-w-lg"
              >
                <div className="text-[11px] uppercase tracking-[0.25em] text-clay mb-6">Project № {p.no}</div>
                <h3 className="font-display text-4xl md:text-5xl lg:text-6xl leading-[1.05] mb-8 tracking-[0.08em] uppercase">
                  {p.name}
                </h3>
                <div className="h-px w-full bg-paper/15 mb-6" />
                <div className="text-[11px] uppercase tracking-[0.25em] text-paper/60 mb-8 flex gap-4">
                  <span>{p.typology}</span>
                  <span className="text-clay">·</span>
                  <span>{p.city}</span>
                  <span className="text-clay">·</span>
                  <span>{p.year}</span>
                </div>
                <p className="text-base md:text-lg font-light leading-relaxed text-paper/80 mb-8">
                  {p.desc}
                </p>
                <div className="text-[11px] uppercase tracking-[0.15em] text-paper/40">{p.stats}</div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Right: Project Image */}
          <div className="relative order-1 md:order-2 h-[35vh] md:h-full w-full overflow-hidden">
            {PROJECTS.map((proj, i) => (
              <motion.div
                key={proj.no}
                className="absolute inset-0"
                initial={false}
                animate={{
                  y: i === active ? "0%" : i < active ? "-100%" : "100%",
                  opacity: i === active ? 1 : 0.4,
                }}
                transition={{ duration: 1.1, ease: [0.83, 0, 0.17, 1] }}
              >
                <img
                  src={proj.img}
                  alt={proj.name}
                  className="h-full w-full object-cover"
                  style={{ filter: "grayscale(30%) contrast(1.1) brightness(0.85)" }}
                />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Progress dots */}
        <div className="absolute left-6 md:left-12 bottom-8 flex items-center gap-3 z-20">
          {PROJECTS.map((_, i) => (
            <div key={i} className={`w-2 h-2 rounded-full transition-all duration-500 ${i === active ? "bg-clay scale-125" : "bg-paper/20"}`} />
          ))}
        </div>
      </div>
    </section>
  );
}
